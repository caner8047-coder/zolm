<?php
/**
 * ZOLM WhatsApp Booster — WooCommerce Ayarları Sayfası
 *
 * Bu dosya yalnızca WC_Settings_Page yüklendikten sonra require edilir.
 */

defined('ABSPATH') || exit;

if (!class_exists('WC_Settings_Page')) {
    return;
}

if (!class_exists('ZOLM_WhatsApp_Settings_Page', false)) {

    class ZOLM_WhatsApp_Settings_Page extends WC_Settings_Page
    {
        public function __construct()
        {
            $this->id = 'zolm_whatsapp';
            $this->label = __('WhatsApp (ZOLM)', 'zolm-whatsapp-booster');
            parent::__construct();
        }

        public function get_settings()
        {
            return [
                [
                    'title' => __('WhatsApp Ayarları', 'zolm-whatsapp-booster'),
                    'type' => 'title',
                    'desc' => __('ZOLM WhatsApp modülü köprü ayarları', 'zolm-whatsapp-booster'),
                    'id' => 'zolm_wa_section',
                ],
                [
                    'title' => __('ZOLM URL', 'zolm-whatsapp-booster'),
                    'desc' => __('ZOLM Booster webhook endpoint URL\'i', 'zolm-whatsapp-booster'),
                    'id' => 'zolm_wa_booster_zolm_url',
                    'type' => 'url',
                    'default' => '',
                    'css' => 'width: 400px;',
                ],
                [
                    'title' => __('Webhook Secret', 'zolm-whatsapp-booster'),
                    'desc' => __('HMAC imza doğrulama anahtarı', 'zolm-whatsapp-booster'),
                    'id' => 'zolm_wa_booster_webhook_secret',
                    'type' => 'password',
                    'default' => '',
                    'css' => 'width: 400px;',
                ],
                [
                    'title' => __('Store ID', 'zolm-whatsapp-booster'),
                    'desc' => __('ZOLM\'daki mağaza ID\'si', 'zolm-whatsapp-booster'),
                    'id' => 'zolm_wa_booster_store_id',
                    'type' => 'number',
                    'default' => 0,
                ],
                [
                    'title' => __('Test Modu', 'zolm-whatsapp-booster'),
                    'desc' => __('Aktif edildiğinde sadece log yazılır, gerçek webhook gönderilmez', 'zolm-whatsapp-booster'),
                    'id' => 'zolm_wa_booster_test_mode',
                    'type' => 'checkbox',
                    'default' => 'no',
                ],
                [
                    'type' => 'sectionend',
                    'id' => 'zolm_wa_section',
                ],
            ];
        }
    }

}
